# MixWatch

Responsive movie, television, anime and Bollywood discovery web app reconstructed from the MixWatch UI/UX blueprint. Built with React and Vite.

## Features
- Netflix-inspired dark UI, responsive navigation and horizontal swipeable rows
- Real movies, TV series and Hindi-language Bollywood movie catalogs via TMDB
- Real anime listings and seasonal anime via Jikan / MyAnimeList
- Debounced title search across available catalogs
- Title detail modal, official YouTube trailer playback where available
- My List and recently played trailer history saved in the browser
- Keyboard accessible controls, reduced-motion support, mobile layout

## Run locally

Install Node.js 20+ and run:

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local address printed by Vite.

## Configure movie, TV and Bollywood catalogs

1. Sign up for a TMDB account at https://www.themoviedb.org/ .
2. Obtain your **API Read Access Token** from your TMDB API settings.
3. Put it in `.env` as `VITE_TMDB_READ_TOKEN=YOUR_TOKEN`.
4. Restart the development server.

**Security:** Vite `VITE_` variables are shipped to the browser. This is appropriate only for credentials you intend to expose publicly. For production, consider a server-side API proxy, rate limiting, and keeping any private credentials exclusively on the server. Never commit `.env`.

Anime uses the public Jikan API without a token. Jikan has rate limits and may temporarily be unavailable. All catalogs depend on their respective services.

## Build and deploy

```bash
npm run build
npm run preview
```

Deploy the generated `dist/` directory to a static host such as Netlify, Cloudflare Pages or Vercel. Set `VITE_TMDB_READ_TOKEN` as a build-time environment variable if you use TMDB directly. Configure the host for a Vite project (`npm run build`, output `dist`).

## GitHub upload

Unzip the archive and upload the **contents** of the `mixwatch-source` folder (not the ZIP itself) to your GitHub repository, or use Git:

```bash
git init
git add .
git commit -m "Add MixWatch web app"
git branch -M main
git remote add origin https://github.com/paidinfullp1-design/MixWatch.git
git push -u origin main
```

If your remote already contains commits, clone it and copy the project files into the clone instead of pushing unrelated histories.

## Content and legal notes

MixWatch is a **discovery and trailer app**, not a licensed full-length streaming service. The Play Trailer button embeds available YouTube trailers. It does not provide full movies or anime episodes. To add full playback, integrate a provider you are authorized to distribute or embed, with its terms and licensing respected. No fake catalog entries or unauthorized stream sources are included.

This is a **reconstruction**, not an export of the original ChatGPT Site source. It implements a useful subset of the prior feature requests. Automatic muted hero video previews, account authentication, cross-device sync, licensed streaming, subtitle/audio track management, and production backend are not implemented.

TMDB data and imagery are supplied by TMDB; this product uses the TMDB API but is not endorsed or certified by TMDB. Anime metadata comes from Jikan/MyAnimeList. Respect provider attribution and API policies when deploying.

## Design reference

https://whimsical.com/guwop-huncho/mixwatch-ui-ux-blueprint-5RgS6wU39MqS3CZhLytqZW
